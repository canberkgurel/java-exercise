public class CircleTester{

public static void main(String[] args) {

// Step 4
Circle c1 = new Circle(1.0);
System.out.println("Area of circle is "+c1.calcArea());

// Step 8
Circle c2 = new Circle(1.0,"blue");
//System.out.println("Area of circle is "+c2.calcArea()+" and colour is "+c2.colour);

// Step 9
//c1.radius = 3.5;
System.out.println("Area of circle is "+c1.calcArea());

// Step 10
//c1.radius = -3.5;
System.out.println("Area of circle is "+c1.calcArea());

// Step 14
c1.setRadius(10);
c1.setRadius(-20);

} // end of main

} // end of CircleTester class