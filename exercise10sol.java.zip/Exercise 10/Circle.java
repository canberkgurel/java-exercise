// for up to Step 9 Circle Class
/*
public class Circle{
double radius;
String colour = "red";
public Circle(double r){
	radius = r;
} // end of Circle(double r)
public Circle(double r,String c){
	radius = r;
	colour = c;
} // end of Circle(double r,String c)
public double calcArea()
{
	return Math.PI*radius*radius;
} // end of calcArea()
} // end of Circle class
*/

// for step 10 onwards

public class Circle{

private double radius;
private String colour = "red";

public Circle(double r){
	radius = r;
} // end of Circle(double r)

public Circle(double r,String c){
	radius = r;
	colour = c;
} // end of Circle(double r,String c)

public double calcArea()
{
	return Math.PI*radius*radius;
} // end of calcArea()

public void printColor()
{
	System.out.println("Colour is "+ colour);
} // end of printColor()

public double getRadius()
{
	return radius;
} 

public String getColour()
{
	return colour;
} 

public void setRadius(double r) {
	if (r < 1) {
	System.out.println( "Error ! illegal value for radius");
	}
	else {
	radius = r;
	System.out.println( "radius set to " + radius);
	}
} // end of setRadius

} // end of Circle class