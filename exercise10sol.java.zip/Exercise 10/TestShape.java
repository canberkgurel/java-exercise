public class TestShape {
  public static void main(String args[]) {

	Shape s = new Shape(2,4);
	s.addCircle(1,"yellow");
	s.addCircle(2,"red");
	s.addRectangle(1,1);
	s.addRectangle(2,2);
	s.addRectangle(7,8);
	s.addCircle(3,"green");
	s.printCircles();
	s.printRectangles();
  }
}