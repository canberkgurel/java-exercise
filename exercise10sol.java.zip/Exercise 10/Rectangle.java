public class Rectangle{
	private double length;
	private double width;
  public Rectangle(double l, double w) {
	length=l;
	width=w;
  }
  public double getPerimeter() {
	return 2*(length+width);
  }

  public double getArea() {
	return length*width;
  }

  public void setData(double l, double w) {
	if(l>0&&w>0){
		length=Math.max(l,w);
		width=Math.min(l,w);
	}
	else
	{
	System.out.println("Error ! illegal value");
	}
  }

  public void showData() {
         System.out.printf("length is %.2f, width is %.2f", length, width);
  }
}// end of Rectangle class