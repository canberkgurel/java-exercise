public class RectangleTester
{
	public static void main(String args[])	{
	  Rectangle r = new Rectangle(10,5);
	  System.out.println("Area of rectangular is "+r.getArea());
	  System.out.println("Perimeter of rectangular is "+r.getPerimeter());
	
	  r.setData(-4,5);
	  System.out.println("Area of rectangular is "+r.getArea());
	  System.out.println("Perimeter of rectangular is "+r.getPerimeter());
	
	  r.setData(7,4);
	  System.out.println("Area of rectangular is "+r.getArea());
	  System.out.println("Perimeter of rectangular is "+r.getPerimeter());
	}
}