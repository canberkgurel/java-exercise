public class Shape
{
	private Circle[] circles;
	private Rectangle[] rectangles;
	private int max_cir;
	private int max_rec;
	private int size_cir;
	private int size_rec;

  public Shape(int c, int r) {
	size_cir=0;
	size_rec=0;
	circles = new Circle[c];
	rectangles = new Rectangle[r];
  }

  public void addCircle(double r,String c) {
	if(size_cir<circles.length)
	{
		circles[size_cir]=new Circle(r,c);
		size_cir++;
	}
	else
	{
	System.out.println("Error! circle maximum limit reached");
	}
  }

  public void addRectangle(double l, double w) {
	if(size_rec<rectangles.length)
	{
		rectangles[size_rec]=new Rectangle(l,w);
		size_rec++;
	}
	else
	{
	System.out.println("Error! rectangle maximum limit reached");
	}
  }

  public void printCircles() {
	for ( int i=0;i<size_cir;i++)
	{
		System.out.printf("circle %d: radius = %.1f, area = %.2f, colour = %s\n",(i+1),circles[i].getRadius(),circles[i].calcArea(),circles[i].getColour());
	}
  }

  public void printRectangles() {
	for ( int i=0;i<size_rec;i++)
	{
		System.out.printf("rectangle %d: perimeter = %.1f, area = %.1f\n",(i+1),rectangles[i].getPerimeter(),rectangles[i].getArea());
	}
  }
}