// start with any required import statements

import java.io.*;
import java.util.*;
// A class to copy a file
public class FileCopierSolution {

  // complete the main method as follows:
  // Using a scanner, prompt the user to enter a name of the source file
  // e.g. "Enter name of file to copy:"
  // -user enters say, file1.txt
  // Then the user is prompted to enter the name of the new file to save
  // the data to, e.g.:
  // "Enter name of the destination file:"

  public static void main(String[] args) {

    Scanner in = new Scanner(System.in);
    System.out.println("Enter the name of the file to copy: ");
    String fileSource = in.nextLine();
    System.out.println("Enter the name of the destination file: ");
    String fileDestination = in.nextLine();


    try {
        // try opening the source and destination files:
        Scanner sc = new Scanner(new File(fileSource));
        FileWriter output = new FileWriter(fileDestination, true);
        // wrap it inside a PrintWriter so we can use println:
        PrintWriter out = new PrintWriter(output);
        // declare a String to store each line read from the source:
        String line = "";
        // continue reading from the source file and writing to the destination file
        // until we reach the end of the source:
        while (sc.hasNext()) {
          line = sc.nextLine();
          out.println(line);
        }
        sc.close(); // close the source file
        out.close(); // close the destination file
    } // end of try block

    // Declare catch blocks to deal with:
    // FileNotFoundException and IOException

    catch (FileNotFoundException e) { // in case the filename is wrong
          System.out.println(e);
    }
    catch (IOException e) { // in case the error is something else
          System.out.println(e);
    } // end of catch block
  }
}
