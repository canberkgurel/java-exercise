// start with any required import statements:


public class CarWriter {

  public static void main(String[] args) {
  // complete the main method as follows:
  // Using a scanner, prompt the user to enter a name and make of car:
  // e.g. "Enter new car details:"
  // -user enters say, Mazda MX5.
  // Save the user-entered information in a String,
  // then, using a FileWriter, open a file called NewCarList.txt
  // and write the string to this file.
  // Finally, close the file.



  // Declare  a catch block to deal with any exception :



  } // end of main
} // end of class
