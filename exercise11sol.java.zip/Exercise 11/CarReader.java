// start with any required import statements:


public class CarReader {
  
  // start of the main method:
  public static void main(String[] args) {
    
    // complete the main method as follows:
    // declare a String to store each line read from the file

    
    // declare a try block that opens the file CarList.txt using a Scanner.
    // Use a loop to read one line at a time and print it out to 
    // the screen. Continue reading until the end of the file is reached.
    // Finally close the file.



    // Declare a catch blocks to deal with any exceptions : 



  } // end of main
} // end of class
