// A class to copy a file
// Start with any required import statements



public class FileCopier {

  // complete the main method as follows:
  // Using a scanner, prompt the user to enter a name of the source file
  // e.g. "Enter name of file to copy:"
  // -user enters say, file1.txt
  // Then the user is prompted to enter the name of the new file to save
  // the data to, e.g.:
  // "Enter name of the destination file:"

  public static void main(String[] args) {




    // Declare a catch block to deal with any exception :



  } // end of main
} // end of class
