import java.util.*;
import java.io.*;

public class TextFile {
  public static void main (String [] args) {
    String str;
    try {
     Scanner s = new Scanner(new File("Grades.txt"));
     while (s.hasNext ( )) {   // read the file until it reaches the end of the file
         str = s.nextLine ( );   // read a line from the file, and store it in the String e
         System.out.println (str);  // print out str
     } //end while
     s.close ();
    }
    catch (Exception e) { }
    
    try {
      System.out.println ("Enter the file name: ");
      Scanner input = new Scanner (System.in);
      String filename = input.nextLine();
      //FileWriter f = new FileWriter("Results.txt", true);
      FileWriter f = new FileWriter(filename);
      PrintWriter p = new PrintWriter (f);
      p.println ("0.5");
      p.flush ();
      p.close ();
    }
    catch (Exception e) { }

  }
}