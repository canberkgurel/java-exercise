// start with any required import statements

import java.io.*;
import java.util.*;
public class CarWriter2 {

  // complete the main method as follows:
  // Using a scanner, prompt the user to enter a name and make of car:
  // e.g. "Enter new car details:"
  // -user enters say, Mazda MX5.
  // Save the user-entered information in a String,
  // then, using a FileWriter, open a file called NewCarList.txt
  // and write the string to this file.
  // Finally, close the file.

  public static void main(String[] args) {

    Scanner in = new Scanner(System.in);
    System.out.println("Enter Car details: ");
    String line = in.nextLine();


    try {
        String fileName = "C:\\Java Course\\test\\NewCarList.txt";
        FileWriter output = new FileWriter(fileName, true);
        output.write(line);
        output.write('\n');
        output.close(); // close the file
    } // end of try block

    // Declare catch blocks to deal with:
    // FileNotFoundException and IOException

    catch (FileNotFoundException e) { // in case the filename is wrong
          System.out.println(e);
    }
    catch (IOException e) { // in case the error is something else
          System.out.println(e);
    } // end of catch block
  }
}