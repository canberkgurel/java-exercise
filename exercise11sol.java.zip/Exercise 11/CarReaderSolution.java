// start with any required import statements

import java.io.*;
import java.util.*;
public class CarReader2 {
  
  //start of the main method:

  public static void main(String[] args) {
    
    //complete the main method as follows:
    // declare a String to store each line read from the file

    String line = null; // initialize a string variable to store lines read from the file
    
    // declare a try block that opens the file CarList.txt
    // using either Scanner or a FileReader-BufferedReader combination.
    // Use a loop to read one line at a time and print it out to 
    // the screen. Continue reading until the end of the file is reached.
    // Finally close the file.
    try {
        String fileName = "C:\\Java Course\\test\\CarList.txt";
        Scanner sc = new Scanner(new File(fileName));
        while (sc.hasNext()) {
          line = sc.nextLine();
          System.out.println(line);
        }
        sc.close(); // close the file
    } // end of try block

    // Declare catch blocks to deal with: 
    // FileNotFoundException and IOException

    catch (FileNotFoundException e) { // in case the filename is wrong
          System.out.println(e);
    }
    catch (IOException e) { // in case the error is something else
          System.out.println(e);
    } // end of catch block
  }
}