public class TestSafeCheck  {

	public static void main (String [ ] args )  {	

	    //create an array of test values:
	    double testData [ ] = { 12.0, -2.3, 15.5, 21.2, -5.6, -7.8 };
        SafeCheck a = new SafeCheck();
        a.printSafe(testData);
	    // Create an instance of SafeCheck using a variable name of your choice.
	    // Pass testData to the SafeCheck printSafe method,
	    // using the instance variable created.
	  
	}

} // end class TestSafeCheck
