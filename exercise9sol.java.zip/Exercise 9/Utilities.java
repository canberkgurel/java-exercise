
public class Utilities {
 	public double[] PowerCalc (double[] v ) {
          double[] p=new double[v.length];
          for(int i=0;i<v.length;i++)
          {
           p[i]=5*v[i];
          }
          return p;

   }


}