public class SafeCheck2 {

	//complete the method
	public void printSafe ( double[] p )  {

          Utilities u = new Utilities();
          double[] out = u.PowerCalc(p);

          System.out.println("Powers are");
          for(int i=0;i<out.length;i++)
          {
           System.out.println(out[i]);
          }

          int safe=1;
          for(int i=0;i<out.length;i++)
          {
           if(out[i]>30)
           { safe=0;
           //System.out.println(i);
           break;}
          }

          if(safe==1)
          {System.out.println("SAFE");}
          else
          {System.out.println("UNSAFE");}

	    // if the sum of the array values is
	    // less than 30 print out the message "UNSAFE"
	    // else print out the message "SAFE"

	}

} // end class SafeCheck
