public class Volt {

    // complete the method
    public void calcAvg ( int[] p )  {
	// use a for Loop to calculate and return the average voltage
	// ...
	// ...
      double sum=0.0;
          for(int i=0;i<p.length;i++)
          {
           sum+=p[i];
          }
          System.out.println("Average is "+ sum/p.length);
    }

} // end of class Volt
