import java.util.Scanner;
public class TestVolt2 {

    public static void main ( String [ ] args )   {
       Scanner input=new Scanner(System.in);
       int[] a = new int[5];
       System.out.println("Enter integers to array");
          for(int i=0;i<a.length;i++)
          {
           a[i]=input.nextInt();
          }
          Volt v= new Volt();
          v.calcAvg(a);
	// Prompt the user to enter 5 integers and store in an array.
	// Create an instance of Volt.
	// Pass the integer array into the calcAvg method of the Volt instance.
	// Print out the value returned.

    }

} // end of class TestVolt
