import java.util.Scanner;
public class TestUtilities {

    public static void main ( String [ ] args )   {
       Scanner input=new Scanner(System.in);
       double[] a = new double[5];
       System.out.println("Enter the voltages");
          for(int i=0;i<a.length;i++)
          {
           a[i]=input.nextDouble();
          }
          Utilities u = new Utilities();
          double[] out = u.PowerCalc(a);

       System.out.println("Power are");
          for(int i=0;i<out.length;i++)
          {
           System.out.println(out[i]);
          }
	// Prompt the user to enter 5 integers and store in an array.
	// Create an instance of Volt.
	// Pass the integer array into the calcAvg method of the Volt instance.
	// Print out the value returned.

    }

} // end of class TestVolt
