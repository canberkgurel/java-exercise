import java.util.Scanner;
public class TestVolt {

    public static void main ( String [ ] args )   {
       Scanner input=new Scanner(System.in);
       int[] a = new int[5];
       System.out.println("Enter integers to array");
          for(int i=0;i<a.length;i++)
          {
           a[i]=input.nextInt();
          }
           double[] b= new double[a.length];
           for(int i=0;i<a.length;i++)
          {
           b[i]=a[i];
          }
          

          Volt v= new Volt();
          SafeCheck s= new SafeCheck();
          Thanks t = new Thanks();
          v.calcAvg(a);
          s.printSafe(b);
          t.printMessage();
	// Prompt the user to enter 5 integers and store in an array.
	// Create an instance of Volt.
	// Pass the integer array into the calcAvg method of the Volt instance.
	// Print out the value returned.

    }

} // end of class TestVolt
