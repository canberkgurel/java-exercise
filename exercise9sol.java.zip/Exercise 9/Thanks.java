public class Thanks {

	public void printMessage ( ) {
	    System.out.println("Thank you for using this program!");
	}

} // end class Thanks
