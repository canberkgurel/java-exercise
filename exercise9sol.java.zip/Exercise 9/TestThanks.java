public class TestThanks  {

	public static void main (String [ ] args)  {
	    // Create and initialise an instance variable of type Thanks.
        Thanks a = new Thanks();
        a.printMessage();
	    // Using the instance variable created above, 
	    // call the printMessage method.
	}

} //end class TestThanks
