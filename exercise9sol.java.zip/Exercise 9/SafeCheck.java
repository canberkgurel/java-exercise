public class SafeCheck  {
	
	//complete the method 
	public void printSafe ( double[] p )  {
          double sum=0.0;
          for(int i=0;i<p.length;i++)
          {
           sum+=p[i];
          }
          if(sum<30)
          {
             System.out.println("SAFE");
           }
           else
           {
                  System.out.println("UNSAFE");
           }
	    // if the sum of the array values is
	    // less than 30 print out the message "UNSAFE"
	    // else print out the message "SAFE"	

	}

} // end class SafeCheck
