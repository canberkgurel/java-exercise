import java.util.Scanner;

public class TestSafeCheck2  {

	public static void main (String [ ] args )  {	

	    //create an array of test values:
       Scanner input=new Scanner(System.in);
       double[] a = new double[5];
       System.out.println("Enter the voltages");
          for(int i=0;i<a.length;i++)
          {
           a[i]=input.nextDouble();
          }
        
        SafeCheck2 s = new SafeCheck2();
        s.printSafe(a);
	    // Create an instance of SafeCheck using a variable name of your choice.
	    // Pass testData to the SafeCheck printSafe method,
	    // using the instance variable created.
	  
	}

} // end class TestSafeCheck
